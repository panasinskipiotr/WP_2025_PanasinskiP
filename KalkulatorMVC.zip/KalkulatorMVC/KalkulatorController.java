import java.awt.event.*;
import javax.swing.JButton;

public class KalkulatorController implements ActionListener {
    private KalkulatorModel model;
    private KalkulatorView view;

    public KalkulatorController(KalkulatorModel m, KalkulatorView v) {
        model = m;
        view = v;
        view.addController(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String input = ((JButton) e.getSource()).getText();
        String current = view.getText();

        try {
            if ("0123456789".contains(input)) {
                view.setText(model.inputDigit(input, current));
            } else if ("+-*/".contains(input)) {
                view.setText(model.inputOperator(input, current));
            } else if (input.equals("=")) {
                view.setText(model.inputOperator("=", current));
            } else if (input.equals("C")) {
                view.setText(model.clearAll());
            } else if (input.equals("CE")) {
                view.setText("");
            } else if (input.equals("<-")) {
                if (current.length() > 0) {
                    view.setText(current.substring(0, current.length() - 1));
                }
            }
        } catch (ArithmeticException ex) {
            view.setText("Błąd: Dzielenie przez 0");
            model.clearAll(); 
        } catch (NumberFormatException ex) {
            view.setText("Błąd");
            model.clearAll();
        }
    }
}