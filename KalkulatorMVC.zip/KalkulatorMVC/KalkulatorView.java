import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class KalkulatorView extends JFrame{
    JTextField textFieldScreen=new JTextField(10);

    JButton button_0=new JButton("0");
    JButton button_1=new JButton("1");
    JButton button_2=new JButton("2");
    JButton button_3=new JButton("3");
    JButton button_4=new JButton("4");
    JButton button_5=new JButton("5");
    JButton button_6=new JButton("6");
    JButton button_7=new JButton("7");
    JButton button_8=new JButton("8");
    JButton button_9=new JButton("9");

    JButton buttonAdd=new JButton("+");
    JButton buttonSub=new JButton("-");
    JButton buttonMultiply=new JButton("*");
    JButton buttonDivide=new JButton("/");

    JButton buttonC=new JButton("C");
    JButton buttonCE=new JButton("CE");
    JButton buttonEquals=new JButton("=");
    JButton buttonBckspc=new JButton("<-");

    public KalkulatorView(){
        JPanel panelButtons=new JPanel(new GridLayout(5,4,5,5));

        panelButtons.add(button_7);
        panelButtons.add(button_8);
        panelButtons.add(button_9);
        panelButtons.add(buttonCE);

        panelButtons.add(button_4);
        panelButtons.add(button_5);
        panelButtons.add(button_6);
        panelButtons.add(buttonAdd);

        panelButtons.add(button_1);
        panelButtons.add(button_2);
        panelButtons.add(button_3);
        panelButtons.add(buttonSub);

        panelButtons.add(new JLabel());
        panelButtons.add(button_0);
        panelButtons.add(new JLabel());
        panelButtons.add(buttonMultiply);

        panelButtons.add(buttonBckspc);
        panelButtons.add(buttonC);
        panelButtons.add(buttonEquals);
        panelButtons.add(buttonDivide);

        JPanel panelMain=new JPanel(new BorderLayout());
        panelMain.add(textFieldScreen,BorderLayout.NORTH);
        panelMain.add(panelButtons,BorderLayout.CENTER);

        setContentPane(panelMain);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        pack();
        setVisible(true);
    }

    public String getText(){
        return textFieldScreen.getText();
    }

    public void setText(String text){
        textFieldScreen.setText(text);
    }

    public void addController(ActionListener c){
        JButton[] digitButtons={
            button_0,button_1,button_2,button_3,button_4,
            button_5,button_6,button_7,button_8,button_9
        };

        for(JButton b:digitButtons)b.addActionListener(c);

        JButton[] ops={
            buttonAdd,buttonSub,buttonMultiply,buttonDivide
        };

        for(JButton b:ops)b.addActionListener(c);

        buttonEquals.addActionListener(c);
        buttonC.addActionListener(c);
        buttonCE.addActionListener(c);
        buttonBckspc.addActionListener(c);
    }
}