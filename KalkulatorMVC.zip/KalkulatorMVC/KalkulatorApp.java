import java.awt.EventQueue;

public class KalkulatorApp{
    public static void main(String[] args){
        EventQueue.invokeLater(()->{
            KalkulatorModel model=new KalkulatorModel();
            KalkulatorView view=new KalkulatorView();
            new KalkulatorController(model,view);
        });
    }
}