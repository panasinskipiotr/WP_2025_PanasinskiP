public class KalkulatorModel {
    private int value1 = 0;
    private int value2 = 0;
    private String operator = "";
    private int state = 1;

    public String inputDigit(String digit, String current) {
        if (current.equals("Błąd: Dzielenie przez 0")) {
            clearAll();
            current = "";
        }

        switch (state) {
            case 1:
                return current + digit;
            case 2:
                state = 3;
                return digit;
            case 3:
                return current + digit;
            case 4:
                operator = "";
                state = 1;
                return digit;
        }
        return current;
    }

    public String inputOperator(String op, String current) {
        if (current.equals("Błąd: Dzielenie przez 0")) {
            return current;
        }

        if (op.equals("=")) {
            if (!operator.isEmpty() && state == 3) {
                value2 = Integer.parseInt(current);
                int result = calculate(value1, value2, operator);
                state = 4;
                operator = "";
                return String.valueOf(result);
            }
            return current;
        }

        switch (state) {
            case 1:
                value1 = Integer.parseInt(current);
                operator = op;
                state = 2;
                return value1 + operator;
            case 2:
                operator = op;
                return value1 + operator;
            case 3:
                value2 = Integer.parseInt(current);
                int result = calculate(value1, value2, operator);
                value1 = result;
                operator = op;
                state = 2;
                return value1 + operator;
            case 4:
                value1 = Integer.parseInt(current);
                operator = op;
                state = 2;
                return value1 + operator;
        }
        return current;
    }

    private int calculate(int v1, int v2, String op) {
        switch (op) {
            case "+": return v1 + v2;
            case "-": return v1 - v2;
            case "*": return v1 * v2;
            case "/":
                if (v2 == 0) {
                    throw new ArithmeticException("Nie dziel przez 0!");
                }
                return v1 / v2;
        }
        return 0;
    }

    public String clearAll() {
        value1 = 0;
        value2 = 0;
        operator = "";
        state = 1;
        return "";
    }
}